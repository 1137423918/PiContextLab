"""Run a CPU-only local model demonstration with a foreground owned server."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
import urllib.request

p=argparse.ArgumentParser();p.add_argument('--server',type=Path,required=True);p.add_argument('--model',type=Path,required=True);p.add_argument('--libraries',type=Path,required=True);p.add_argument('--node',type=Path,required=True);p.add_argument('--dataset-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--protocol',type=Path,default=Path('examples/model-protocol.json'));p.add_argument('--request-timeout-ms',type=int,default=90000);a=p.parse_args()
protocol=json.loads(a.protocol.read_text());request_ceiling=sum(c['max_calls'] for c in protocol['cases']);output_ceiling=sum(c['max_calls']*c['max_output'] for c in protocol['cases']);assert 1<=request_ceiling<=7 and 1000<=a.request_timeout_ms<=180000
a.output.mkdir(parents=True,exist_ok=False)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert sha(a.server)=='89ff842d29d30f8ee1af38c501b4d68bf4802994ef322fa706867f7a83dfb746'
assert sha(a.model)=='9f1c9b5bd32d1c37502b525a677b3245a1b91fb7b71c7464f4264647998e7a06'
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']='';env['LD_LIBRARY_PATH']=str(a.libraries);env['METRICLAB_MODEL_URL']=f'http://127.0.0.1:{port}/v1';env['METRICLAB_MODEL_ID']='metriclab-qwen3-4b';env['METRICLAB_CONTEXT_WINDOW']='8192'
env['METRICLAB_MODEL_PROTOCOL']=str(a.protocol.resolve());env['METRICLAB_REQUEST_TIMEOUT_MS']=str(a.request_timeout_ms)
command=[str(a.server),'--model',str(a.model),'--host','127.0.0.1','--port',str(port),'--alias','metriclab-qwen3-4b','--n-gpu-layers','0','--threads','2','--threads-batch','2','--ctx-size','8192','--parallel','1','--jinja','--no-warmup','--no-webui']
status={'GPU_used':False,'real_model':True,'request_ceiling':request_ceiling,'output_ceiling':output_ceiling,'protocol_sha256':sha(a.protocol),'request_timeout_ms':a.request_timeout_ms,'server_sha256':sha(a.server),'model_sha256':sha(a.model),'CPU_affinity':sorted(os.sched_getaffinity(0))}
server=None;child=None;began=time.monotonic()
try:
 with (a.output/'server.log').open('wb') as log:
  server=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
  for _ in range(120):
   if server.poll() is not None:raise RuntimeError('Model server exited')
   try:
    with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=1) as r:
     if r.status==200:break
   except (OSError,urllib.error.URLError):time.sleep(.5)
  else:raise TimeoutError('Model readiness cap')
  child=subprocess.Popen([str(a.node),'dist/scripts/real-model.js',str(a.dataset_root),str(a.output/'cases')],env=env)
  status['driver_exit_code']=child.wait(timeout=700)
  if status['driver_exit_code']!=0:raise RuntimeError('Model driver failed')
  result=json.loads((a.output/'cases/results.json').read_text());assert result['total_reserved']<=request_ceiling
  status.update(finished=True,total_reserved=result['total_reserved'],cases=[{'id':c['case'],'status':c['job']['status'],'requests':len(c['calls']),'report':bool(c['report'])} for c in result['cases']])
except BaseException as e:
 status['error']={'type':type(e).__name__,'message':str(e)}
finally:
 for proc in [child,server]:
  if proc and proc.poll() is None:
   proc.terminate()
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)
 status.update(terminal=True,wall_seconds=round(time.monotonic()-began,3),owned_servers_after=int(server is not None and server.poll() is None))
 (a.output/'run.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status))
raise SystemExit(0 if status.get('finished') and not status.get('error') else 2)
