# PiMetricLab

基于 **Pi 1.6.0 + DeepSeek API** 的电商经营指标调查工作台：从订单明细出发，明确指标与可比时间范围，比较经营变化，拆解国家/商品贡献，生成可以回查 SQL 和结果哈希的复盘报告。

这是一项独立的 Agent 应用工程项目。Pi 负责模型和工具循环；应用负责指标正确性、数据版本、固定额度、持久化恢复和人工复核边界。

**阅读入口：**[完整中文讲解](docs/handbook.md) · [DeepSeek 运行时接入](docs/deepseek.md) · [验收规格](docs/acceptance.md) · [研究参考](docs/references.md) · [验证与限制](docs/validation.md) · [简历及面试](docs/resume.md)

## 能做什么

- 接入显式 CSV 与来源清单，计算不可变数据集身份和实际质量统计。
- 提供净销售额、正向销售额、退货金额、订单数、已识别客户数、客单价六种指标；金额用 DECIMAL/BigInt，订单按订单号去重。
- 用真实 Pi Agent 调用领域工具；只接受白名单指标、日期和维度，无任意 SQL 或 shell 工具。
- 拦截不完整末月、非法日期、不可加和的订单分组；贡献包含剩余分组并与总额核对。
- SQLite 保存消息、工具结果、模型请求预留、事件与封存报告；支持中断恢复、旧写入者拦截、取消、固定额度。
- Web 工作台显示执行过程和证据，刷新恢复选中的任务，可导出自包含 HTML；审核绑定具体报告版本。

## 快速运行

要求 Node **22.19+**（实际验证 22.23.5）。当前开发约束下，安装、编译、测试、浏览器和推理均在授权服务器执行。

```bash
npm ci --ignore-scripts --no-audit --no-fund
npm run check
npm run build
npm test
```

先显式取得 [UCI Online Retail 原始 ZIP](https://archive.ics.uci.edu/static/public/352/online+retail.zip)，在独立 Python 环境安装 `openpyxl==3.1.5` 与 `et-xmlfile==2.0.0`，转换完整数据：

```bash
python scripts/prepare_uci.py --archive /path/to/online-retail.zip --output /path/to/retail-data
node dist/src/cli.js ingest /path/to/retail-data/transactions.csv /path/to/retail-data/source-manifest.json
```

运行真实 Agent：

```bash
export DEEPSEEK_API_KEY='YOUR_KEY'
export METRICLAB_MODEL_URL=https://api.deepseek.com
export METRICLAB_MODEL_ID=deepseek-flash
export METRICLAB_MAX_CONTEXT_BYTES=16384
export METRICLAB_REQUEST_TIMEOUT_MS=90000
npm start
```

Pi 运行时直接通过官方 DeepSeek API 完成模型调用，无需本地模型、权重下载或显卡。当前显式使用 non-thinking 工具调用。打开 `http://127.0.0.1:4318`，输入：

> 比较 2011 年 10 月与 11 月的 net_sales，使用完整日历月口径，按 country 拆解变化，保留证据并提交调查报告。

未配置模型时为只读检查模式。无需推理的运行时演示可使用：

```bash
node dist/src/cli.js serve --scripted-control
```

页面会明确显示 `scripted-control`。该模式固定调查 2011 年 10/11 月，通过真实 Pi 工具循环完成，不是自然语言理解或模型效果验证。

![工作台](docs/images/investigation-desktop.png)

## 数据与证据

完整 UCI 数据 **541,909 行**；原始数据、DuckDB 文件和密钥不放入 Git。来源为 Daqing Chen (2015)，DOI [10.24432/C5BW33](https://doi.org/10.24432/C5BW33)，CC BY 4.0。本项目保留原始行，不自动删除重复行；退货、缺失客户与非正价格按公开口径处理。

首次独立核对覆盖六个指标 × 两个期间、29 个国家分组及六项质量计数，见 [原始工作簿计算](evidence/uci-oracle.json) 和[验证记录](docs/validation.md)。脚本化 provider、HTTP 故障服务和真实模型运行分别记录。

## 工程边界

这是可运行的单租户本机/可信内网分析工作台。当前不提供多租户鉴权、任意数据源连接、支付写入、集群调度或生产客户证明。HTTP 默认仅监听回环地址；若需要公网部署，应先补齐身份认证与权限隔离。贡献拆解用于解释统计变化，不能自动证明因果。

依赖和上游身份冻结于 [package-lock.json](package-lock.json) 与 [upstream-lock.json](upstream-lock.json)。未修改上游 Pi。项目自身采用 MIT；第三方许可见 [THIRD_PARTY_NOTICES](THIRD_PARTY_NOTICES/pi-MIT.txt)。
