# PiContextLab：Pi Agent Core 的上下文与工具策略改造

本文是当前项目主线。经营指标应用是验证客户端，不能把接一个 Agent SDK 当作框架改进。用户已明确选择“上下文管理与工具选择策略”，运行时直接使用 DeepSeek API。

## 改动位置与已有能力

固定 Pi 1.6.0 的完整 Agent Core 源码保留在 [vendor/pi-agent-core](../vendor/pi-agent-core)，原文件哈希见 [UPSTREAM.json](../vendor/pi-agent-core/UPSTREAM.json)，MIT 原许可一并保留。派生版本为 `1.6.0-contextlab.3`，不是上游发布或已合入 PR。原研究克隆保持不变。

上游已有 `transformContext`、工具调用屏障、完整的 `pi-durable` 持久化 Harness、摘要压缩，以及部分工具输出限制。本项目不把这些已有能力说成原创。

本次新增的是轻量 Agent Core 中的**原生请求策略入口**：在规范化 transcript 后、真实模型请求前，产生预算内的 provider 视图和该轮执行工具白名单。权威对话记录保持完整。选中的工具声明与实际可执行工具由核心一起检查，而不是只在业务 prompt 里建议少用工具。

## 两个策略组件

1. **工具选择：**按当前任务对名称、描述与参数文档作词法检索，在工具数量和 schema 字节双预算下选择完整依赖组。始终可用的工具显式固定；漏召回时通过 `discover_tools` 检索并在下一轮暴露候选 schema。
2. **上下文管理：**合并但保留全部 system 指令；大段文本工具输出按 SHA256 外置，保留可读取的引用；预算仍不足时，以完整旧 user turn 为单位按相关性/大小与新近性选择，当前用户轮次整体保留。原文和历史索引支持显式、限量、带完整性检查的读取。

这不是新提出的 BM25 算法，也不声称外置就天然无损完成所有任务。原文不丢失与模型能否成功取回、正确使用，是两个需要分别验证的问题。预算度量是 UTF-8 上下文 JSON 字节，实际输入 token 和成本以 provider usage 另行记录。

## 核心接线

- [agent.ts](../vendor/pi-agent-core/src/agent.ts)：注册策略及其通用检索/读取工具。
- [agent-loop.ts](../vendor/pi-agent-core/src/agent-loop.ts)：模型边界调用策略，并把同一轮的选择落实到工具执行集合；声明和执行集合不一致时拒绝发出。
- [model-context.ts](../vendor/pi-agent-core/src/model-context.ts)：通用策略协议，不包含任何电商字段。
- [tool-router.ts](../vendor/pi-agent-core/src/tool-router.ts)：词法排名与工具依赖预算。
- [context-budget.ts](../vendor/pi-agent-core/src/context-budget.ts)：完整事务检查、工具输出外置和历史打包。
- [context-artifacts.ts](../vendor/pi-agent-core/src/context-artifacts.ts)：内容身份、会话范围存储协议与限量 recall。
- [budgeted-policy.ts](../vendor/pi-agent-core/src/budgeted-policy.ts)：组合策略和逐请求审计数据。

没有策略时保留原版路径。对照包以 `@pi-context-lab/upstream-agent-core` 精确别名安装原始 npm 1.6.0，避免把改造后的代码冒充原版基线。

## 安全与协议边界

工具检索不是用户权限系统。宿主仍决定完整注册表和业务权限；策略只会进一步缩小某一轮的可执行集合。没有被该轮声明的注册工具，即使模型输出了名字也不会执行。

历史打包不按任意最后 N 条消息截断：assistant 的工具调用与对应结果必须完整。孤立、重复或缺失结果的导入记录会报错。当前轮次、system 指令和必要工具在外置后仍放不下时，明确拒绝请求，而不是偷偷丢掉用户约束。

外置内容按会话隔离，读取时检查 ID、哈希、长度；JSON pointer 只遍历自有属性；Unicode 读取按 code point 截取。长内容不被摘要模型改写，但检索策略仍可能漏掉任务需要的信息，需要通过实际评测观察。

## 与验证客户端的关系

PiMetricLab 通过这项原生策略运行领域工具。SQLite 只是通用 artifact store 的一个适配器；把客户端换成文档分析或代码维护，不需要改框架中的业务字段。上下文选择记录由宿主在发请求前按任务 owner/epoch 事务保存，重启恢复工具调用时使用该轮已保存的工具集合。

## 验证要求

至少需要三类证据：原版与改造版的协议/执行边界对照，公开真实工具目录的检索与 schema 开销评测，以及相同 DeepSeek 模型下的任务、token、成本和失败对照。单元控制、公开检索子集和真实业务集成分别报告，不能用一个漂亮的压缩比例代替任务效果。

实现已在服务器编译和验证，实际结果以原始记录和 [validation.md](validation.md) 为准；本文不提前宣称效果提升。
