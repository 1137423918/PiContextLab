# Pi 运行时直接使用 DeepSeek API

本项目的模型运行路径为：**Pi Agent → pi-ai 的 OpenAI-compatible adapter → 官方 DeepSeek API**。没有本地部署大模型，也没有把 DeepSeek 仅当作离线调研助手。数据库查询、证据校验和任务持久化仍在应用服务器完成。

## 当前模型与接口

2026-11-25 实际鉴权读取 `/models` 成功，返回 `deepseek-flash` 和 `deepseek-v4-pro`。默认选择 `deepseek-flash`，基地址 `https://api.deepseek.com`；模型目录结果不是推理效果验证。

模型名称、工具调用和默认 thinking 行为参考 [官方模型页](https://api-docs.deepseek.com/quick_start/pricing/)、[Tool Calls](https://api-docs.deepseek.com/guides/tool_calls/) 与 [Thinking Mode](https://api-docs.deepseek.com/guides/thinking_mode/)。供应商可能更新同名模型的实际版本；原始 assistant 消息中的模型元数据与运行日期一起保存。

## 配置

```bash
export DEEPSEEK_API_KEY='YOUR_KEY'
export METRICLAB_MODEL_URL=https://api.deepseek.com
export METRICLAB_MODEL_ID=deepseek-flash
export METRICLAB_CONTEXT_WINDOW=1048576
export METRICLAB_MAX_CONTEXT_BYTES=65536
export METRICLAB_CONTEXT_POLICY=upstream
export METRICLAB_ARTIFACT_SEARCH=0
export METRICLAB_REQUEST_TIMEOUT_MS=90000
npm start
```

密钥只在后端环境中读取，不进入 `Model` 对象、任务配置指纹、API 返回、浏览器或报告。项目中的 [.env.example](../.env.example) 只有空值和公开配置；应用不会自动读取工作目录里的任意 `.env` 文件。源码和报告都不包含实际密钥。

`METRICLAB_MODEL_URL`/ID 省略时默认使用官方 DeepSeek 和 `deepseek-flash`；生产环境仍建议显式配置。没有后端密钥时网页为检查模式。`--scripted-control` 是独立的固定控制演示，不会偷偷当作 API 成功结果。

## 工具调用设置

本版显式发送 `thinking: { type: 'disabled' }`，以验证业务工具协议与完整流程。官方模型默认可能启用 thinking，不能只给 Pi 设置 off 就假定 provider 的默认也关闭。因此在 adapter 的 `samplingParams` 中明确指定，并用真实适配器加受控 fetch 检查最终请求。

本版使用常规工具调用，不启用 Beta strict。应用自己的 schema、日期、指标、证据校验仍是权威边界。若将来启用 thinking，需要保持工具轮次所需的 reasoning 状态传递，重新冻结配置并测试；当前不声称已验证 thinking 模式研究或模型对比。

## 额度和记录

[实际 API 集成方案](../examples/deepseek-protocol.json) 在发出请求前固定两个业务用例，总请求上限 9、输出 token 上限合计 7,680、单次规范化上下文 JSON 上限 16 KiB、完整响应截止 90 秒。两个用例分别验证月度净销售额/国家贡献，以及时间与指标不明确时的澄清。

每次请求在 SQLite 预留，provider 内部重试为 0，未知尝试继续计入额度。上下文超限在发出前拒绝。应用保留模型返回的 token usage 和按公开峰时单价计算的估计成本；它不是供应商账单，也不是所有部署环境的精确货币预算。

无本地模型加载、训练或 GPU 占用。旧 CPU 模型尝试仅保留为历史失败记录；用户明确运行方式后已停止，不能算作 DeepSeek 的成绩。

## 框架研究版本

上面的 `deepseek-protocol.json` 属于原版 SDK 应用基线，现已关闭。框架 v1 的业务与上下文方案、v2 的 `native-v2-protocol.json` 与 `context-v2-protocol.json` 分别冻结并运行，全部结果见 [validation.md](validation.md)。v2 共 22 次真实请求（业务 5、审计 17），不追加自动付费重试。v3 只修复逐路径错误处理，未做真实 API 复测。

## 运行研究与业务应用的区别

本项目不以两个集成用例声称模型准确率。后续若研究不同 DeepSeek 模型或 thinking 策略，应单独冻结任务集、模型、预算、评分规则和失败处理，再做可比对照。业务应用使用真实 API 只是基础条件，不自动证明某个研究结论。

## v4 真实结果与当前默认配置

先行发布的 [abd69e2方案](https://github.com/1137423918/PiContextLab/blob/abd69e28ee05773536b523def5008e90241b8369/docs/evaluation-v4-plan.md)执行23次真实请求：新业务报告3次、澄清2次、审计18次。完整上下文两个审计通过，native-read/native-search均未通过。日志中模型没有使用新增字段定位工具，反复分页消耗了额度；完整分析见 [验证](validation.md)。

研究关闭后，真实API入口和Runner默认改为 `upstream` 完整上下文，字段定位默认关闭。仍使用本项目派生core的无策略路径，业务口径、额度和持久化照常工作。需要研究预算策略时显式设置：

```bash
export METRICLAB_CONTEXT_POLICY=budgeted
export METRICLAB_ARTIFACT_SEARCH=0  # 设为1另行开启字段定位
```

未知枚举值及在upstream模式单独启用字段定位会拒绝。模型配置、contextMode和artifactSearch绑定任务，旧任务不会静默切换配置。`--scripted-control`显式使用预算策略演示工程路径，不调用模型。当时37项控制包含完整上下文路径和显式预算恢复；没有为默认值调整追加付费模型请求。

core9在budgeted模式新增同一assistant批次共享8,192内容JSON字节的回读/字段定位预算；正常执行与恢复按原整批分配。upstream模式不启用该组预算。它只约束该组最终content，尚未预留完整下一轮空间，不是token上限或模型成功保证。schema拒绝的有界反馈在两种模式都显式开启；该版本71项工程控制及CPU对照见[验证记录](validation.md)。预算配置及工具元数据也进入任务指纹，旧任务不自动切换。

core10在budgeted模式显式开启响应后的纯回读空间规划：实际参数返回后，投影完整事务并按剩余量收紧8KiB上限，正常执行前持久保存，恢复复用具体响应的方案。当前80项控制通过；256字节/调用余量只面向通常内建回读包装，自定义hook、变换及工具集变化仍可能导致下一轮硬拒绝，不作token或模型效果保证。真实API仍默认full，历史关闭研究不重试，详见[规划机制](framework.md#contextlab10响应返回后的纯回读空间规划)。

严格复现v4研究请检出原始abd69e2提交，使用冻结协议和全新输出目录；当前默认值已变，不能直接用当前入口重跑后声称复现原条件。既有23请求原结果保持关闭。


当前core11增加有界可行目标搜索与紧预算回读元数据，85项工程控制通过；九业务工具的结构化研究客户端仍继承实际Pi宿主和原封存限制。先行源码后真实16请求研究已关闭，完整两项事实核对通过，预算两项均未通过（读前拒绝/错误贡献）；默认真实入口继续full，详细原始轨迹见[验证记录](validation.md)。密钥仍只进入后端运行时，不需要本地模型或GPU。
