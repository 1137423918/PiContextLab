import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile,rm } from 'node:fs/promises';
import { BriefRunner,briefSubmitSchema } from '../src/brief-client.js';
import { parse } from '../src/domain.js';
import { scriptedProvider } from '../src/demo.js';
import { fixture,comparison } from './fixtures.js';
import { gradeBrief,type BriefCase,type BriefOracleCase } from '../scripts/brief-evaluation.js';
import type { Report } from '../src/store.js';

test('structured validation client registers nine real operations and preserves source metadata boundaries',async()=>{
 const f=await fixture();try{const job=f.store.create(f.dataset.id,'Structured client fixture',8,1200,comparison),claim=f.store.claim(job.id);const runner=new BriefRunner(f.store,f.warehouse,scriptedProvider(comparison));const tools=runner.tools(claim);assert.equal(tools.length,9);assert.equal(new Set(tools.map(t=>t.name)).size,9);const quality=tools.find(t=>t.name==='dataset_quality');assert.ok(quality);const result=await quality.execute('quality',{});assert.ok(JSON.stringify(result.content).includes('unknown_customers'));const list=tools.find(t=>t.name==='list_saved_evidence');assert.ok(list);assert.ok(JSON.stringify((await list.execute('list',{})).content).includes('evidence'));assert.throws(()=>parse(briefSubmitSchema,{title:'Plain legacy body',evidence_ids:['source'],interpretation:'Legacy free prose',hypotheses:[]}));
 }finally{f.store.close();await rm(f.root,{recursive:true,force:true});}
});

test('structured brief grading rejects no report, incomplete or source-corrupt evidence',async()=>{
 const protocol=JSON.parse(await readFile('examples/brief-study-protocol.json','utf8')) as {cases:BriefCase[]};const c=protocol.cases[0]!;const oracle:BriefOracleCase={facts:{},breakdowns:{},check:{baseline:'0',current:'0'}};assert.equal(gradeBrief(null,c,oracle,'0'.repeat(64)).passed,false);const report:Report={id:'x',job:'x',dataset:'ds_'+'0'.repeat(24),title:'Partial',evidence:[],interpretation:'{}',hypotheses:[],created:0};assert.equal(gradeBrief(report,c,oracle,'0'.repeat(64)).passed,false);
});
