# 多指标月度复盘：运行前方案

研究对象是一个新的业务工作流：比较2011年三月与四月的net_sales、gross_sales、returns，每个指标同时取得国家Top10与商品Top12，最终一份报告包含3个比较和6个贡献分解。它要求跨多个工具结果保持证据身份，验证gross_sales−returns=net_sales。没有加入无关填充文本或旧研究问题。

[机器协议](../examples/pressure-business-protocol.json)固定完整上下文64KiB与预算上下文24KiB、顺序full→budgeted、字段搜索关闭。每个任务最多8次请求，每次最多2,048输出token、超时20秒，合计最多16次请求/32,768输出token。Pi直接接官方DeepSeek API，thinking关闭、temperature0、自动重试0。不同预算不能读成同预算算法准确率对照；只有一项工作流，不推导泛化。

发请求前，Python CSV/Decimal独立计算六个组成部分的全部分组。评分核对9个不同来源证据、准确比较/维度/limit、Top/OTHER/总额、每条保存SQL分组/期间行和gross−returns恒等式；oracle不进入模型输入。报告叙述与因果质量不评分，仍需人审。

CPU预检通过真实Pi Runner按固定批次执行inspect→3comparisons→6breakdowns→submit。提交所用evidence ID只从provider视图的原始id或source_identity.id读取，禁止绕过视图从Store取答案。两个配置必须通过全量算术与报告检查，预算配置必须实际产生pressure和spill且视图不超24KiB，才能考虑真实API。

预检是程序可行性控制，不是模型结果。若core6不可行，保留失败，不为该版本发请求，不修改案例、预算或评分预期来制造可行性；只有定位通用程序缺陷后，才能以明确版本修复并在相同控制中验证，保留前后两份输出。任何源码修订必须在付费请求前公开冻结。真实模型自行决定批次，可能不触发压力或失败；原样报告，绝不追加质量重试或提高上限。

完整记录Pi适配器边界输入（非HTTP body）、每次持久预留、usage（包含缓存输入）、准备视图字节、外置次数与源身份。大原始记录以gzip保存，公开summary和hash可核对；密钥不入记录。费用只作冻结单价估计，不是账单。本研究不重新运行已关闭v1/v2/v4/business-v6/检索诊断，全部工作在授权服务器受限CPU执行，不部署本地模型、不使用GPU。
